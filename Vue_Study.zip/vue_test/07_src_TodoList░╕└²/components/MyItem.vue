<template>
    <div>
        <li>
            <label>
                <!-- 这里不建议用v-model,虽然也能实现功能, -->
                <!-- 但是修改了props接收过来的todo中的done,有点违反vue的规范, -->
                <!-- 为保持良好习惯最好连接收过来的对象里面的属性都不要改 -->
                <!-- 否则一旦习惯了有一天接收了基础类型习惯性操作就会报错出bug -->
                <!-- <input type="checkbox" v-model="todo.done"> -->
                <input type="checkbox" :checked="todo.done" @change="handleCheck(todo.id)">
                <span>{{ todo.title }}</span>
            </label>
            <button class="btn btn-danger" style="display: none;" @click="handleDelete(todo.id)">删除</button>
        </li>
    </div>
</template>

<script>
export default {
    name: 'MyItem',
    props: ['todo', 'checkTodo','todoDelete'],
    methods:{
        handleCheck(id){
            this.checkTodo(id);
        },
        handleDelete(id){
            this.todoDelete(id)
        }
    }
}
</script>

<style scoped>
/* item */
.btn {
  display: inline-block;
  padding: 4px 12px;
  margin-bottom: 0;
  font-size: 14px;
  line-height: 20px;
  text-align: center;
  vertical-align: middle;
  cursor: pointer;
  box-shadow: inset 0 1px rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);
  border-radius: 4px;
}

.btn-danger {
  color: #fff;
  background-color: #da4f49;
  border: 1px solid #bd362f;
}

.btn-danger:hover {
  color: #fff;
  background-color: #bd362f;
}
.btn:focus {
  outline: none;
}
li {
    list-style: none;
    height: 36px;
    line-height: 36px;
    padding: 0 5px;
    border-bottom: 1px solid #ddd;
}

li label {
    float: left;
    cursor: pointer;
}

li label li input {
    vertical-align: middle;
    margin-right: 6px;
    position: relative;
    top: -1px;
}

li button {
    float: right;
    display: none;
    margin-top: 3px;
}

li::before {
    content: initial;
}

li:last-child {
    border-bottom: none;
}

li:hover{
    background-color: #ccc;
}
li:hover button{
    display: block !important;
}
</style>