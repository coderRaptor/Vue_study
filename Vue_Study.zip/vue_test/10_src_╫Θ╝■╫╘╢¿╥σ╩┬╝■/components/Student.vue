<template>
  <div class="student">
    <h2>学生姓名: {{ name }}</h2>
    <h2>学校性别: {{ sex }}</h2>
    <h2>{{ number }}</h2>
    <button @click="add">点我number++</button>
    <button @click="sendStudentName">点我传递学生名给App父组件</button>
    <button @click="unbind">解绑事件</button>
    <button @click="death">点我销毁该Student组件实例</button>
  </div>
</template>

<script>
export default {
  name: "Student",
  data() {
    return {
      name: '张三',
      sex: '男',
      number: 0
    };
  },
  methods:{
    add(){
      console.log('add回调被调用了');
      this.number++
    },
    death(){
      // 销毁了当前Student组件实例,销毁后所有Student组件实例上绑定的自定义事件和原生事件全部失效
      this.$destroy()
    },
    sendStudentName(){
      // 触发Student组件实例身上的atguigu事件
      // 或者说触发当前组件实例上的atguigu事件并且传参
      this.$emit('atguigu', this.name, 666, 888, 900)
      // this.$emit('demo')
    },
    unbind(){
      this.$off('atguigu') // 解绑一个该组件实例上的自定义事件
      // this.$off(['atguigu', 'demo']) //解绑多个该组件实例上的自定义事件(必须用数组包裹作为参数)
      // this.$off() // 解绑所有该组件实例上的自定义事件
    },
  }
};
</script>
<style scoped>
  .student{
    background-color: pink;
    padding: 5px;
    margin-top: 30px;
  }
</style>
