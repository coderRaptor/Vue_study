<template>
  <div class="app">
    <h1>{{ msg }},{{ studentName }}同学</h1>
    <!-- 通过父组件给子组件传递函数类型的props实现: 子给父传递数据 -->
    <School :getSchoolName="getSchoolName" />
    <!-- 通过父组件给子组件绑定一个自定义事件实现：子给父传递数据(第一种写法, 用@或v-on直接绑定) -->
    <!-- <Student @atguigu="getStudentName" /> -->

    <!-- 通过父组件给子组件绑定一个自定义事件实现：子给父传递数据(第一种写法, 使用ref) -->
    <!-- 如果想给组件标签绑定原生事件必须加.native修饰符(vue2),否则即便和原生名字一样vue2照样认为你在绑定自定义事件 -->
    <Student ref="student" @demo="m1" @click.native="show" />
  </div>
</template>
<script>
// 引入组件
import School from "./components/School.vue";
import Student from "./components/Student.vue";
export default {
  name: "App",
  components: { School, Student },
  data() {
    return {
      msg: '你好哇',
      studentName: ''
    }
  },
  methods: {
    show(){
      alert('你好哇嘿嘿嘿')
    },
    m1(){
      console.log('demo被调用了');
    },
    getSchoolName(schoolName) {
      console.log(`App收到了学校名:${schoolName}`);
    },
    getStudentName(studentName, ...params) {
      console.log(this);
      this.studentName = studentName
      console.log(`App收到了学生名:${studentName} ${params}`);
    },
  },
  mounted() {
    // 绑定自定义事件
    // 用ref实现可以进行按条件绑定,如延迟时间后再绑定,而@直接在组件上绑定则不够灵活
    // 因为getStudentName是定义在methods中,所以调用时里面的this固定为当前组件实例,在这里即为App
    this.$refs.student.$on('atguigu', this.getStudentName) 
    // 下面两种都是不推荐写法,虽然可以箭头函数,但是和原生规则有冲突,
    // 原生的绑定事件一般要this指向绑定元素,用的function,所以尽量不要破坏习惯
    // this.$refs.student.$on('atguigu', (studentName, ...params) => {
    //   console.log(this);//指向App组件实例
    //   this.studentName = studentName
    //   console.log(`App收到了学生名:${studentName} ${params}`);
    // })
    // this.$refs.student.$on('atguigu', function(studentName, ...params) {
    //   console.log(this); //指向Student组件实例
    //   console.log(`App收到了学生名:${studentName} ${params}`);
    // })
    // 如果想只触发一次
    // this.$refs.student.$once('atguigu', this.getStudentName)
  }
};
</script>
<style lang="less">
.app {
  background-color: grey;
  padding: 5px;
}
</style>
