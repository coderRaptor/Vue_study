<template>
  <div>
    <h2 @click="showName">学校名称: {{ name }}</h2>
    <h2>学校地址: {{ address }}</h2>
  </div>
</template>

<script>
import {mixin, hehe} from '../mixin.js'
export default {
  name: "School",
  data() {
    console.log(this);
    return {
      name: '尚硅谷',
      address: '北京' // 没有被混合hehe中的上海覆盖, 混合无冲突属性则叠加,有冲突以自身为主
    };
  },
  mixins:[mixin, hehe],
  // 生命周期钩子函数例外,无论有没有冲突都叠加,并且执行顺序永远是混合进来的优先
  mounted() {
    console.log('你好哇!');
  },
};
</script>
