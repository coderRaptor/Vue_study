export const mixin = {
    methods: {
        showName() {
            alert(this.name)
        }
    },

    mounted() {
        console.log('你好哇!!!!!');
    },
}
export const hehe = {
    data() {
        return {
            x: 200,
            y: 200,
            address: '上海' 
        }
    },
}
