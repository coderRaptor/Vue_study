import Vue from 'vue'
import App from './App.vue'
// import {mixin, hehe} from './mixin'
Vue.config.productionTip = false;

// 全局混合 所有用到的组件都混合
// Vue.mixin(mixin);
// Vue.mixin(hehe);
new Vue({
  render: h => h(App)
}).$mount('#app')

