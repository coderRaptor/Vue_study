<template>
  <div class="demo">
    <h2>学校名称: {{ name }}</h2>
    <h2>学校地址: {{ address }}</h2>
  </div>
</template>

<script>
import pubsub from 'pubsub-js';
export default {
  name: "School",
  data() {
    return {
      name: '尚硅谷atguigu',
      address: '北京' 
    };
  },
  mounted(){
    // this.$bus.$on('receive', (data)=>{
    //   console.log('School组件实例收到了数据:'+data);
    // })
    this.pid = pubsub.subscribe('studentName', (msgName, data)=>{
      // 这个库中这里的回调的第二个参数才是收到publish的数据,第一个是消息名
      console.log('收到studentName消息了,收到数据为:', data);
    })
  },
  beforeDestroy() {
    // this.$bus.$off('receive')
    pubsub.unsubscribe(this.pid)
  },
};
</script>

<style scoped>
  .demo{
    background-color: skyblue;
  }
</style>

