<template>
  <h2>我是Home的内容</h2>
</template>

<script>
export default {
    name:'Home'
}
</script>

<style>

</style>