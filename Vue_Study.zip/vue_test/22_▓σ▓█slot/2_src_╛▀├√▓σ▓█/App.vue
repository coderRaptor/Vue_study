<template>
  <div class="container">
    <Category title="美食">
      <img slot="center" src="https://img1.baidu.com/it/u=2917927840,408067598&fm=253&fmt=auto&app=138&f=JPEG?w=670&h=447" alt="">
      <a slot="footer" href="http://www.atguigu.com">更多美食</a>
    </Category>
    <Category title="游戏">
      <ul slot="center">
        <li v-for="(game, index) of games" :key="index">{{ game }}</li>
      </ul>
      <div class="foot" slot="footer">
        <a href="http://www.atguigu.com">单机游戏</a>
        <a href="http://www.atguigu.com">网络游戏</a>
      </div>
    </Category>
    <Category title="电影">
      <video slot="center" controls src="https://media-cdn-zspms.kurogame.com/pnswebsite/website2.0/video/1692720000000/hw6aw8luskyxhlmtoc-1692758304849.mp4"></video>
      <!-- v-slot:footer可以简写为 #footer -->
      <!-- v-slot必须在template中才能使用 -->
      <!-- slot和v-slot不一样, slot可以写在任意html结构标签中,且可以多个, v-slot只能写在template中 -->
      <template v-slot:footer>
        <div class="foot">
          <a href="http://www.atguigu.com">经典</a>
          <a href="http://www.atguigu.com">热门</a>
          <a href="http://www.atguigu.com">推荐</a>
        </div>
        <h4>欢迎前来观影</h4>
      </template>
    </Category>
  </div>
</template>
<script>
import Category from './components/Category'
export default {
  name: "App",
  data() {
    return {
      foods: ['火锅', '烧烤', '小龙虾', '牛排'],
      games: ['红色警戒', '穿越火线', '劲舞团', '超级玛丽'],
      films: ['《教父》', '《拆弹专家》', '《你好,李焕英》', '《尚硅谷》']
    }
  },
  components: { Category }
};
</script>

<style scoped>
.container,.foot {
  display: flex;
  justify-content: space-around;
}

video {
  width: 100%;
}

img{
    width: 100%;
    height: auto;
}

h4{
  text-align: center;
}
</style>
