<template>
  <div class="container">
    <Category title="游戏">
      <template scope="atguigu">
        <ul>
          <li v-for="(game, index) of atguigu.games" :key="index">{{ game }}</li>
        </ul>
      </template>
    </Category>
    <Category title="游戏">
      <template scope="{games}">
        <ol>
          <li v-for="(game, index) of games" :key="index">{{ game }}</li>
        </ol>
      </template>
    </Category>
    <Category title="游戏">
      <!-- slot-scope和scope功能是一样的,只不过slot-scope是新的,scope是旧一点的 -->
      <!-- slot-scope 或 scope都只能写在template标签中,注意template不参与html结构,解析时Vue会帮你去掉 -->
      <!-- 插槽标签中传入的属性都被汇总到slot-scope 或 scope 的对象atguigu中,下面 {games} 是解构赋值-->
      <template slot-scope="{games}">
          <h4 v-for="(game, index) of games" :key="index">{{ game }}</h4>
      </template>
    </Category>
  </div>
</template>
<script>
import Category from './components/Category'
export default {
  name: "App",
  components: { Category }
};
</script>

<style scoped>
.container,.foot {
  display: flex;
  justify-content: space-around;
}

video {
  width: 100%;
}

img{
    width: 100%;
    height: auto;
}

h4{
  text-align: center;
}
</style>
