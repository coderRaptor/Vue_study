<template>
    <div>
        <h1>当前求和为{{ sum }}</h1>
        <h3>当前求和为{{ bigSum }}</h3>
        <h3>我在{{ school }},正在学{{ subject }}</h3>
        <select v-model.number="n">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
        </select>
        <button @click="increment">+</button>
        <button @click="decrement">-</button>
        <button @click="incrementOdd">当前求和为奇数再加</button>
        <button @click="incrementWait">等一等再加</button>
    </div>
</template>

<script>
import {mapState, mapGetters} from 'vuex'
export default {
    name: 'Count',
    data() {
        return {
            n: 1, //用户选择的数字
        }
    },
    computed:{
        // 靠程序员手写
        // sum(){
        //     return this.$store.state.sum
        // },
        // school(){
        //     return this.$store.state.school
        // },
        // subject(){
        //     return this.$store.state.subject
        // },

        // 利用vuex中的mapState批量生成,从state中读取数据,返回值是对象
        // (参数为对象的写法)
        // 配置对象中key为要设置的计算属性名,value为要从state中读取的key
        // ...mapState({sum:'sum',school:'school',subject:'subject'}),
        // 如果设置的计算属性名字和读取state的中的属性名一致可以用下面的写法
        // (参数为数组的写法)
        ...mapState(['sum','school','subject']),
        /** ******************************************************************************* */
        // 通过计算属性读取getters中的属性也是同理
        // bigSum(){
        //     return this.$store.getters.bigSum
        // },
        // ...mapGetters({bigSum:'bigSum'}),      
        ...mapGetters(['bigSum'])
    },
    methods: {
        increment() {
            this.$store.commit('JIA', this.n)
        },
        decrement() {
            this.$store.commit('JIAN', this.n)
        },
        incrementOdd() {
            this.$store.dispatch('jiaOdd', this.n)
        },
        incrementWait() {
            this.$store.dispatch('jiaWait', this.n)
        },
    },
    mounted(){
        console.log('Count',this);
        const x = mapState({sum:'sum',school:'school',subject:'subject'})
        console.log(x);
    }
}
</script>

<style scoped>
button {
    margin-left: 5px;
}
</style>