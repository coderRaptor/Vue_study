// 该文件专门用于创建整个应用的路由器
import VueRouter from "vue-router";
import About from '../pages/About'
import Home from '../pages/Home'
import Message from '../pages/Message'
import News from '../pages/News'
import Detail from '../pages/Detail'

// 创建并导出一个路由器
export default new VueRouter({
    routes:[
        {
            path:'/about',
            component:About
        },
        {
            path:'/home',
            component:Home,
            children:[
                {
                    path:'message',
                    component:Message,
                    children:[
                        {
                            // 命名路由可以简化路由的跳转,但是path路径较长时才能体现优势
                            // 所以路径较短的一般正常写路径跳转, 不用命名路由
                            name:'xiangqing',
                            path:'detail',
                            component:Detail,

                            // props的第一种写法, 值为对象,该对象中所有key-value都会以props的形式传给Detail组件
                            // (不常用,数据通常是写死的)
                            // props:{a:'1',b:'hello'}

                            // props的第二种写法, 值为boolean, 若为true, 就会把该路由组件收到的所有params参数,以props的形式传给Detail组件
                            // (不常用,因为缺少了query)
                            // props:true

                            // props的第三种写法, 值为函数, 会自动把该Detail组件的 $route 作为实参传入该props函数，并且以props的形式传给Detail组件
                            // (常用, params和query兼顾,数据动态)
                            props($route){
                                let {query} = $route
                                return {
                                    id:query.id,
                                    title:query.title
                                }
                            }
                        }
                    ]
                },
                {
                    path:'news',
                    component:News
                }
            ]
        },
    ]
})