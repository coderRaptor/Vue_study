import Vue from 'vue'
import App from './App.vue'

// 引入store,导入时不写入口则默认index,而store里有index,故可省略
import store from './store'
Vue.config.productionTip = false;
new Vue({
  render: h => h(App),
  store
}).$mount('#app')

