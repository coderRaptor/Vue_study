// 该文件用于创建Vuex中最为核心的store
// 引入Vue核心库
import Vue from 'vue'
// 应用Vuex插件
Vue.use(Vuex)
// 引入Vuex
import Vuex from 'vuex'
// 准备actions——用于响应组件中的动作
const actions = {
    // actions里面可以写业务逻辑
    // 这两个没有业务逻辑,可以在组件中直接commit联系mutations改变state中的数据
    // jia(context, value) {
    //     console.log('actions中的jia被调用了', context, value);
    //     context.commit('JIA', value)
    // },
    // jian(context, value) {
    //     console.log('actions中的jian被调用了', context, value);
    //     context.commit('JIAN', value)
    // },
    jiaOdd(context, value) {
        console.log('actions中的jiaOdd被调用了', context, value);
        console.log('处理一些逻辑1');
        context.dispatch('demo1', value)
    },
    demo1(context,value){
        console.log('处理一些逻辑2');
        context.dispatch('demo2', value)
    },
    demo2(context,value){
        if (context.state.sum % 2) {
            context.commit('JIA', value)
        }
    },
    jiaWait(context, value) {
        console.log('actions中的jiaWait被调用了', context, value);
        setTimeout(() => {
            context.commit('JIA', value)
        }, 500)
    }
}
// 准备mutations——用于操作数据（state）
const mutations = {
    // mutations当中只做修改,不做业务逻辑判断(这是规范)
    JIA(state, value) {
        console.log('mutations中的JIA被调用了', state, value);
        state.sum += value
    },
    JIAN(state, value) {
        console.log('mutations中的JIAN被调用了', state, value);
        state.sum -= value
    }
}
// 准备state——用于存储数据
const state = {
    sum: 0
}
// 创建并导出store
export default new Vuex.Store({
    actions,
    mutations,
    state
})