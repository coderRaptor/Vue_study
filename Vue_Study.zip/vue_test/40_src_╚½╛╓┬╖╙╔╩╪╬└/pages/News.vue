<template>
    <ul>
      <li :style="{opacity}">欢迎学习Vue</li>
      <li>news001<input type="text"></li>
      <li>news002<input type="text"></li>
      <li>news003<input type="text"></li>
    </ul>
</template>

<script>
export default {
    name:'News',
    data() {
      return {
        opacity:1
      }
    },
    beforeDestroy() {
      console.log('News组件实例即将被销毁');
    },
    // 路由组件独有的两个生命周期函数(生命周期钩子)
    // 特别注意: 只有设置了缓存的路由组件才有激活和失活两个状态
    // 该其他路由组件切换到该路由组件时,称该路由组件被激活,通俗理解就是该路由组件呈现在页面时即被激活
    // 该路由组件被切换掉其他路由组件时,称该路由组件失活了,通俗理解就是该路由组件不呈现在页面时即失活
    // 因为News组件实例不会被销毁,所以在此案例中把定时器的设置和清除写在激活和失活钩子中最合适,
    // 如果写在beforeDestroy中清除那么由于不会销毁该路由组件,当该路由组件不呈现在页面时,定时器还在执行,降低效率。
    // 该路由组件激活时调用
    activated() {
      this.timer = setInterval(()=>{
        console.log('@');
        this.opacity -= 0.01
        if(this.opacity <= 0) this.opacity = 1
      },16)
    },
    // 该路由组件失活时调用
    deactivated() {
      clearInterval(this.timer)
    },
}
</script>

<style>

</style>