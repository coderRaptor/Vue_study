const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  // 现在vue规定组件名必须由多个单词组成,不能单个单词,否则语法检查错误
  lintOnSave:false, // 关闭语法检查
  pages: {
    index: {
      // page 的入口
      entry: 'src/main.js',
    },
  },

  // 开启代理服务器(方式一)
  // 这种代理方式的弊端为: 
  // 1.不能控制是否走代理, 
  //    并且开启的代理服务器以public为根路径,如果public有跟请求路径中文件重名则直接响应该public中的文件,
  //    此时代理服务器不会向目的服务器发送请求
  // 2. 只能固定代理服务器向一个目的服务器发送请求
  // devServer: {
  //   proxy: 'http://localhost:5000'
  // },

  // 开启代理服务器(方式二)
  devServer:{
    proxy:{
      '/atguigu':{ // 匹配所有以'/atguigu'开头的请求路径(端口号后面的开头)
        target: 'http://localhost:5000',
        pathRewrite:{'^/atguigu': ''},
        ws: true, // 用于支持 websocket
        changeOrigin: true //用于控制请求头中的host值
      },
      '/demo':{ // 匹配所有以'/demo'开头的请求路径
        target: 'http://localhost:5001',
        pathRewrite:{'^/demo': ''},
        ws: true, // 用于支持 websocket
        changeOrigin: true //用于控制请求头中的host值
      }
    }
  }
})
