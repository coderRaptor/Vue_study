// 该文件用于创建Vuex中最为核心的store
// 引入Vue核心库
import Vue from 'vue'
// 应用Vuex插件
Vue.use(Vuex)
// 引入Vuex
import Vuex from 'vuex'
// 准备actions——用于响应组件中的动作
const actions = {
    jiaOdd(context, value) {
        console.log('actions中的jiaOdd被调用了', context, value);
        console.log('处理一些逻辑1');
        context.dispatch('demo1', value)
    },
    demo1(context,value){
        console.log('处理一些逻辑2');
        context.dispatch('demo2', value)
    },
    demo2(context,value){
        if (context.state.sum % 2) {
            context.commit('JIA', value)
        }
    },
    jiaWait(context, value) {
        console.log('actions中的jiaWait被调用了', context, value);
        setTimeout(() => {
            context.commit('JIA', value)
        }, 500)
    }
}
// 准备mutations——用于操作数据（state）
const mutations = {
    // mutations当中只做修改,不做业务逻辑判断(这是规范)
    JIA(state, value) {
        console.log('mutations中的JIA被调用了', state, value);
        state.sum += value
    },
    JIAN(state, value) {
        console.log('mutations中的JIAN被调用了', state, value);
        state.sum -= value
    },
    ADD_PERSON(state,value){
        console.log('mutations中的ADD_PERSON被调用了');
        state.personList.unshift(value)
    }
}
// 准备state——用于存储数据
const state = {
    sum: 0,
    school:'尚硅谷',
    subject:'前端',
    personList:[
        {id:'001',name:'张三'}
    ]
}
// 准备getters——用于将state中的已有数据进行计算得到新值（类型computed）
const getters = {
    bigSum(state){
        return state.sum*10
    }
}
// 创建并导出store
export default new Vuex.Store({
    actions,
    mutations,
    state,
    getters
})