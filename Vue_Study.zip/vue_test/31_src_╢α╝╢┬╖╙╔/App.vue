<template>
  <div>
    <div class="row">
      <Banner/>
    </div>
    <div class="row">
      <div class="col-xs-offset-2 col-xs-2">
        <div class="list-group">
          <!-- 原始方法使用a标签实现页面跳转 -->
          <!-- <a href="./about.html" class="list-group-item active">About</a> -->
          <!-- <a href="./home.html" class="list-group-item">Home</a> -->

          <!-- 使用Vue中的router-link标签实现组件展示 -->
          <router-link to="/about" class="list-group-item" active-class="active">About</router-link>
          <router-link to="/home" class="list-group-item" active-class="active">Home</router-link>
        </div>
      </div>
      <div class="col-xs-6">
        <div class="panel">
          <div class="paner-body">
            <!-- 指定组件的呈现位置 -->
            <router-view></router-view>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>
<script>
import Banner from './components/Banner'
export default {
  name: "App",
  components:{Banner}
};
</script>


