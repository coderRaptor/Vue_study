<template>
  <div>
    <ul>
        <li>
            <a href="/message1">message1</a>&nbsp;&nbsp;
        </li>
        <li>
            <a href="/message2">message2</a>&nbsp;&nbsp;
        </li>
        <li>
            <a href="/message3">message3</a>&nbsp;&nbsp;
        </li>
    </ul>
  </div>
</template>

<script>
export default {
    name:'Message'
}
</script>

<style>

</style>