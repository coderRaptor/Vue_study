<template>
  <div>
    <ul>
        <li v-for="m of messageList" :key="m.id">
            <!-- 跳转路由并携带params参数, to的字符串写法 -->
            <!-- <router-link :to="`/home/message/detail/${m.id}/${m.title}`">{{ m.title }}</router-link>&nbsp;&nbsp; -->

            <!-- 跳转路由并携带query参数, to的对象写法(推荐,因为可读性更高) -->
            <!-- 注意: 这里如果是用params参数,那么必须使用命名空间写法,否则出问题,这是个坑 -->
            <router-link :to="{
                // 用命名路由方式跳转(path路径较长时体现优势)
                name:'xiangqing',
                query:{
                    id:m.id,
                    title:m.title
                }
            }">{{ m.title }}</router-link>&nbsp;&nbsp;
            <button @click="pushShow(m)">push查看</button>
            <button @click="replaceShow(m)">replace查看</button>
        </li>
    </ul>
    <hr>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
    name:'Message',
    data() {
        return {
            messageList:[
                {id:'001', title:'消息001'},
                {id:'002', title:'消息002'},
                {id:'003', title:'消息003'}
            ]
        }
    },
    methods:{
        pushShow(m){
            // console.log(this.$router);
            this.$router.push({
                name:'xiangqing',
                query:{
                    id:m.id,
                    title:m.title
                }
            })
        },
        replaceShow(m){
            this.$router.replace({
                name:'xiangqing',
                query:{
                    id:m.id,
                    title:m.title
                }
            })
        }
    },
    beforeDestroy(){
        console.log('Message组件实例即将被销毁');
    },
    activated(){
        console.log('Message路由组件实例被激活了');//因为该组件没有被设置缓存实例的缘故所以该钩子永远不会执行
    },
    deactivated(){
        console.log('Message路由组件实例失活了');//因为该组件没有被设置缓存实例的缘故所以该钩子永远不会执行
    }
}
</script>

<style>

</style>