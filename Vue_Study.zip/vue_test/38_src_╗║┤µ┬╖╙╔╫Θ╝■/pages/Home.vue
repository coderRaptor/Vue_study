<template>
  <div>
    <h2>Home组件内容</h2>
    <div>
      <ul class="nav nav-tabs">
        <li>
          <!-- <router-link replace class="list-group-item" active-class="active" to="/home/news">News</router-link> -->
          <router-link class="list-group-item" active-class="active" to="/home/news">News</router-link>
        </li>
        <li>
          <!-- <router-link replace class="list-group-item" active-class="active" to="/home/message">Message</router-link> -->
          <router-link class="list-group-item" active-class="active" to="/home/message">Message</router-link>
        </li>
      </ul>
      <!-- 如果keep-alive标签不写include属性标明里面的router-view哪些组件需要缓存，那么默认将所有组件都缓存 -->
      <!-- 但是很多组件没必要缓存，只需要缓存那些有数据输入的，比如有input的，防止切换路由组件后被销毁数据丢失 -->
      <!-- include里面写路由组件的name属性值(组件名)，标明该组件需要缓存，切换时不要销毁 -->
      <!-- 在这里Message路由组件切换到News时Message路由组件实例被销毁,而News路由组件被切换到Message组件时News组件实例会缓存起来不会销毁 -->
      <keep-alive include="News">
        <router-view></router-view>
      </keep-alive>

      <!-- 缓存多个路由组件写法 -->
      <!-- <keep-alive :include="['News','Message']">
        <router-view></router-view>
      </keep-alive> -->
    </div>
  </div>
</template>

<script>
export default {
    name:'Home',
    // beforeDestroy() {
    //   console.log('Home组件实例即将被销毁');
    // },
    // mounted(){
    //   console.log('Home组件实例挂载完毕',this);
    //   window.homeRoute = this.$route
    //   window.homeRouter = this.$router
    // }
}
</script>

<style>

</style>