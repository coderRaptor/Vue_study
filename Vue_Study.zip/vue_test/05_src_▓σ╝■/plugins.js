// 导出插件对象 插件本质上就是一个对象
export default {
    install(Vue, x, y, z) {
        // 当main.js中调用Vue.use(插件对象,...),Vue会帮你调用插件的中的install方法,
        // 并且把Vue构造函数作为第一个参数传入,第二个参数开始按照Vue.use的第二个参数开始接收
        // 但是只有第一个参数是必须接收的,其他可以省略
        console.dir(Vue);
        console.log(x,y,z);// 1 2 3
        // 定义全局过滤器,使得在任何一个Vue实例挂载的容器都可以使用
        Vue.filter('mySlice', function (val) {
            return val.slice(0, 4);
        })

        // 定义全局指令(多个Vue实例都能使用)
        Vue.directive('fbind', {
            // 指令与元素成功绑定时调用(一上来)
            bind(element, binding) {
                element.value = binding.value;
            },
            // 指令所在元素被插入页面时调用
            inserted(element, binding) {
                element.focus();
            },
            // 指令所在的模板被重写解析时调用
            update(element, binding) {
                element.value = binding.value;
            }
        })

        // 定义全局混入
        Vue.mixin({
            data(){
                return {
                    x:100,
                    y:100
                }
            }
        })

        // 给Vue原型上添加一个方法(vm和组件实例就都能用了)
        Vue.prototype.hello = () => {alert('你好啊')}
    }
}