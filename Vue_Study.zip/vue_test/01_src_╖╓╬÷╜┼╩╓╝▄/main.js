// 注意区分commonjs与es6模块化的区别,
// 导入时如果用的是commonjs语法,入口文件为导入库中package.json中的"main"
// 导入时如果用的是es6模块化语法,入口文件为导入库中package.json中的"module"
// 还有动态引用及静态引用区别,导入值的区别等,去掘金收藏详细看
import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

/*
  关于不同版本的Vue:

    1.vue.js与vue.runtime.xxx.js的区别:
        (1).vue.js是完整版的Vue,包含: 核心功能+模板解析器
        (2).vue.runtime.xxx.js是运行版的Vue,只包含: 核心功能:没有模板解析器

    2.因为vue.runtime.xxx.js没有模板解析器,所以不能使用template配置项,需要使用
      render函数接收到createElement函数去指定具体内容
*/
new Vue({
  render: h => h(App),
  // render(createElement){
  //   return createElement('h1','你好哇')
  // }
  // render: createElement => createElement('h1','你好哇')
  // render: q => q('h1','你好哇')
}).$mount('#app')
