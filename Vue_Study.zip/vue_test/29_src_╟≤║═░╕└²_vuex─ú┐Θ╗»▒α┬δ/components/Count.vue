<template>
    <div>
        <h1>当前求和为{{ sum }}</h1>
        <h3>当前求和为{{ bigSum }}</h3>
        <h3>我在{{ school }},正在学{{ subject }}</h3>
        <h3 style="color: red">下方人员总数为{{ personList.length }}</h3>
        <select v-model.number="n">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
        </select>
        <button @click="increment(n)">+</button>
        <button @click="decrement(n)">-</button>
        <button @click="jiaOdd(n)">当前求和为奇数再加</button>
        <button @click="jiaWait(n)">等一等再加</button>
    </div>
</template>

<script>
import { mapState, mapGetters, mapMutations, mapActions } from 'vuex'
export default {
    name: 'Count',
    data() {
        return {
            n: 1, //用户选择的数字
        }
    },
    computed: {
        ...mapState('countAbout',['sum', 'school', 'subject']),
        ...mapState('personAbout',['personList']),
        ...mapGetters('countAbout',['bigSum'])
    },
    methods: {
        ...mapMutations('countAbout',{ increment: 'JIA', decrement: 'JIAN' }),
        ...mapActions('countAbout',['jiaOdd', 'jiaWait'])
    },
    mounted() {
        console.log('Count', this);
        // const x = mapState('countAbout',{ sum: 'sum', school: 'school', subject: 'subject' })
        // console.log(x);
    }
}
</script>

<style scoped>
button {
    margin-left: 5px;
}
</style>