<template>
  <div>
    <h1>人员列表</h1>
    <h3 style="color: red">上方求和总数为{{ sum }}</h3>
    <input type="text" placeholder="请输入名字" v-model="name">
    <button @click="addPerson">添加一个人</button>
    <button @click="addPersonWang">添加一个姓王的人</button>
    <button @click="addPersonServer">随机添加一个人名</button>
    <h3>人员列表中第一个人名为: {{ firstPersonName }}</h3>
    <ul>
        <li v-for="p of personList" :key="p.id">{{ p.name }}</li>
    </ul>
  </div>
</template>

<script>
// import { mapState, mapMutations } from 'vuex';
import {nanoid} from 'nanoid'
export default {
    name:'Person',
    data() {
        return {
            name:''
        }
    },
    computed:{
        personList(){
            return this.$store.state.personAbout.personList
        },
        sum(){
            return this.$store.state.countAbout.sum
        },
        // ...mapState('personAbout',['personList'])
        // ...mapState('count',['sum'])
        firstPersonName(){
            return this.$store.getters['personAbout/firstPersonName']
        }
    },
    methods:{
        addPerson(){
            if(!this.name) return alert('请输入姓名再添加哦~~~')
            let personObj = {id:nanoid(),name:this.name}
            // 这里基本没有逻辑业务判断,没必要联系actions了,直接联系mutations操作state中对应数据
            // 其实是有的,比如上面的判断名字是否空,或者再加些其他判断,那么判断业务逻辑交给actions
            // 只是这里写的比较少判断,索性直接联系mutations操作state中的数据了
            this.$store.commit('personAbout/ADD_PERSON', personObj)
            // this.ADD_PERSON(personObj)
        },
        // ...mapMutations('personAbout',['ADD_PERSON'])

        addPersonWang(){
            if(!this.name) return alert('请输入姓名再添加哦~~~')
            let personObj = {id:nanoid(),name:this.name}
            this.$store.dispatch('personAbout/addWang', personObj)
        },
        addPersonServer(){
            this.$store.dispatch('personAbout/addServer')
        }
    }
}
</script>

<style>

</style>