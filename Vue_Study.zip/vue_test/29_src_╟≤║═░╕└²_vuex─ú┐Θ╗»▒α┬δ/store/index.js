// 该文件用于创建Vuex中最为核心的store
// 引入Vue核心库
import Vue from 'vue'
import countOptions from './count'
import personOptions from './person'
// 应用Vuex插件
Vue.use(Vuex)
// 引入Vuex
import Vuex from 'vuex'
// 创建并导出store
export default new Vuex.Store({
    modules:{
        countAbout: countOptions,
        personAbout: personOptions
    }
})