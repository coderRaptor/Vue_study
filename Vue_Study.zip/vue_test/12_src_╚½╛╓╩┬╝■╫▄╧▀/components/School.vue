<template>
  <div class="demo">
    <h2>学校名称: {{ name }}</h2>
    <h2>学校地址: {{ address }}</h2>
  </div>
</template>

<script>
export default {
  name: "School",
  data() {
    return {
      name: '尚硅谷atguigu',
      address: '北京' 
    };
  },
  mounted(){
    this.$bus.$on('receive', (data)=>{
      console.log('School组件实例收到了数据:'+data);
    })
  },
  beforeDestroy() {
    // 销毁前一定要解绑总线上为该组件实例服务的事件
    // 因为为该School组件服务传递数据的事件是绑定在总线上的
    // 不会因为School组件实例的销毁而失效,必须手动在该组件实例销毁时解绑
    this.$bus.$off('receive')
  },
};
</script>

<style scoped>
  .demo{
    background-color: skyblue;
  }
</style>

