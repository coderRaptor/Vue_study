<template>
  <div class="demo">
    <h2>学生姓名: {{ name }}</h2>
    <h2>学校性别: {{ sex }}</h2>
    <button @click="sendStudentName">点我传递学生姓名给Student组件实例</button>
  </div>
</template>

<script>
export default {
  name: "Student",
  data() {
    return {
      name: '张三',
      sex: '男'
    };
  },
  methods:{
    sendStudentName(){
      this.$bus.$emit('receive', this.name)
    }
  }
};
</script>
<style scoped>
  .demo{
    background-color: orange;
  }
</style>
