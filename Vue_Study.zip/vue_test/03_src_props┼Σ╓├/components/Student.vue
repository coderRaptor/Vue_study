<template>
  <div>
    <h1>{{ msg }}</h1>
    <h2>学生名称: {{ name }}</h2>
    <h2>学校年龄: {{ myAge }}</h2>
    <h2>学校性别: {{ sex }}</h2>
    <button @click="updateAge">尝试修改得到的年龄</button>
  </div>
</template>

<script>
  export default {
    name: "Student",
    data() {
      console.log(this);
      return {
        msg:'我是尚硅谷的学生',
        // Vue会优先获取props上接收的属性添加到组件实例中,再对data数据进行获取,
        // 所以这里可以访问到接收的属性,用接收的属性值作为值再写入插值语句中,
        // 方便在不修改接收属性的前提下修改页面对应数据
        myAge:this.age
      };
    },
    methods:{
      updateAge(){
        // 虽然说通过props接收回来的属性会添加到组件实例上,其值可以修改
        // 但是Vue不建议修改接收的属性,虽然结果一样可以修改成功,但控制台会发出警告错误
        // this.age++;

        // 但是如果有业务需求
        // 所以一般到data上弄个新的叫myAge,再对其修改
        this.myAge+10;
      }
    }
    // 简单声明接收
    // props:['name', 'age', 'sex']

    // 接收的同时对数据进行类型限制
    // props:{
    //   name:String,
    //   age:Number,
    //   sex:String
    // }
    
    // 接收的同时对数据: 类型限制+默认值指定+必要性限制
    // props:{
    //   name:{
    //     type:String,
    //     // 一般required不会和default一起用,因为如果必要传值,就没有默认一说
    //     required:true
    //   },
    //   age:{
    //     type:Number,
    //     default:99
    //   },
    //   sex:{
    //     type:String,
    //     default:'male'
    //   }
    // }
  };
</script>
