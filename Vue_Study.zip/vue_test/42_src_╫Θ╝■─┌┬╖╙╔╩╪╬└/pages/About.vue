<template>
  <h2>我是About的内容</h2>
</template>

<script>
export default {
  name: 'About',
  // beforeDestroy() {
  //   console.log('About组件实例即将被销毁');
  // },
  // mounted(){
  //   console.log('About组件实例挂载完毕',this);
  //   window.aboutRoute = this.$route
  //   window.aboutRouter = this.$router
  // },

  // 一定是由路由规则控制切换的组件(路由组件)
  // 进入守卫: 通过路由规则, 进入(切换)到该组件之前调用
  beforeRouteEnter(to, from, next) {
    console.log('About---beforeRouteEnter', to, from);
    if (to.meta.isAuth) {
      if (localStorage.getItem('school') === 'atguigu') {
        next()//放行,允许切换
      } else {
        alert('学校名必须是atguigu,否则无权限查看')
        // next({name:'guanyu'}) //跳转到name为guanyu的路由规则的组件
      }
    } else {
      next()
    }
  },

  // 离开守卫: 通过路由规则, 离开该组件之前调用
  beforeRouteLeave(to, from, next) {
    console.log('About---beforeRouteLeave', to, from);
    next()
  }
}
</script>

<style></style>