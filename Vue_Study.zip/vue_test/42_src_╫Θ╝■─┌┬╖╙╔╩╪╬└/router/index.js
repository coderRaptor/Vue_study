// 该文件专门用于创建整个应用的路由器
import VueRouter from "vue-router";
import About from '../pages/About'
import Home from '../pages/Home'
import Message from '../pages/Message'
import News from '../pages/News'
import Detail from '../pages/Detail'

// 创建并导出一个路由器
const router = new VueRouter({
    routes: [
        {
            name: 'guanyu',
            path: '/about',
            component: About,
            meta: {isAuth:true, title: '关于' }
        },
        {
            name: 'zhuye',
            path: '/home',
            component: Home,
            children: [
                {
                    name: 'xinwen',
                    path: 'news',
                    component: News,
                    meta: { isAuth: true, title: '新闻' },
                    // 独享路由守卫,只有前置,没有后置
                    beforeEnter(to, from, next) { //判断当前路由是否需要进行权限控制
                        // to 是目标路由组件的$route属性对象
                        // from 是原来路由组件的$route属性对象
                        console.log('beforeEnter', to, from);
                        if (to.meta.isAuth) {
                            if (localStorage.getItem('school') === 'atguigu') {
                                next()//放行,允许切换
                            } else {
                                alert('学校名必须是atguigu,否则无权限查看')
                                // next({name:'guanyu'}) //跳转到name为guanyu的路由规则的组件
                            }
                        } else {
                            next()
                        }
                    }
                },
                {
                    name: 'xiaoxi',
                    path: 'message',
                    component: Message,
                    meta: { isAuth: true, title: '消息' },
                    children: [
                        {
                            meta: { title: '详情' },
                            name: 'xiangqing',
                            path: 'detail',
                            component: Detail,
                            props($route) {
                                let { query } = $route
                                return {
                                    id: query.id,
                                    title: query.title
                                }
                            }
                        }
                    ]
                }
            ]
        },
    ]
})

// 全局前置路由守卫————初始化时被调用、每次路由切换之前被调用
// router.beforeEach((to, from, next) => {
//     // to 是目标路由组件的$route属性对象
//     // from 是原来路由组件的$route属性对象
//     console.log('beforeEach', to, from);
//     // 如果切换到xinwen路由组件或xiaoxi路由组件则先判断localStorage中存储的school是否对应,不对应不切换
//     // 路由规则中的meta对象用于存储程序员自己写的数据,我们可以在路由规则里的meta中设置一个属性判定是否需要权限检测
//     // meta属性会在对应路由规则的组件的$route属性对象中出现,在这里可以判断从目标路由组件的$route属性对象的meta检测是否需要权限检测
//     if (to.meta.isAuth) {
//         if (localStorage.getItem('school') === 'atguigu') {
//             next()//放行,允许切换
//         } else {
//             alert('学校名必须是atguigu,否则无权限查看')
//             //next({name:'guanyu'}) //跳转到name为guanyu的路由规则的组件
//         }
//     } else {
//         next()
//     }
// })

// 全局后置路由守卫————初始化时被调用、每次路由成功切换之后被调用
router.afterEach((to, from) => {
    // 没有next参数,因为已经成功切换了,不存在是否允许切换的问题
    console.log('afterEach', to, from);
    document.title = to.meta.title || '硅谷系统'
})
export default router