<template>
    <div>
        <h1>当前求和为{{ sum }}</h1>
        <h3>当前求和为{{ bigSum }}</h3>
        <h3>我在{{ school }},正在学{{ subject }}</h3>
        <select v-model.number="n">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
        </select>
        <button @click="increment(n)">+</button>
        <button @click="decrement(n)">-</button>
        <button @click="jiaOdd(n)">当前求和为奇数再加</button>
        <button @click="jiaWait(n)">等一等再加</button>
    </div>
</template>

<script>
import { mapState, mapGetters, mapMutations, mapActions } from 'vuex'
export default {
    name: 'Count',
    data() {
        return {
            n: 1, //用户选择的数字
        }
    },
    computed: {
        // 利用vuex中的mapState批量生成,从state中读取数据,返回值是对象
        // (参数为对象的写法)
        // 配置对象中key为要设置的计算属性名,value为要从state中读取的key
        // ...mapState({sum:'sum',school:'school',subject:'subject'}),
        // 如果设置的计算属性名字和读取state的中的属性名一致可以用下面的写法
        // (参数为数组的写法)
        ...mapState(['sum', 'school', 'subject']),
        /** ******************************************************************************* */
        // 通过计算属性读取getters中的属性也是同理
        // bigSum(){
        //     return this.$store.getters.bigSum
        // },
        // ...mapGetters({bigSum:'bigSum'}),      
        ...mapGetters(['bigSum'])
    },
    methods: {
        // 程序员亲自写
        // increment() {
        //     this.$store.commit('JIA', this.n)
        // },
        // decrement() {
        //     this.$store.commit('JIAN', this.n)
        // },
        // mapMutations生成的是这样的,所以这里要在模板中传参
        // increment(value) {
        //     this.$store.commit('JIA', value)
        // },
        // 借助mapMutations生成对应的方法, 方法中会调用commit去联系mutations
        // (参数为对象的写法)
        ...mapMutations({ increment: 'JIA', decrement: 'JIAN' }),
        // (参数为数组写法) 必须key与value一致才能用此法,这里是因为mutations中有JIA和JIAN
        // ...mapMutations(['JIA', 'JIAN']),
        /** ************************************************************************************** */
        // 亲自写
        // incrementOdd() {
        //     this.$store.dispatch('jiaOdd', this.n)
        // },
        // incrementWait() {
        //     this.$store.dispatch('jiaWait', this.n)
        // },
        // 靠api生成的,同理
        // mapActions生成的是这样的,所以这里要在模板中传参
        // incrementOdd(value) {
        //     this.$store.dispatch('jiaOdd', value)
        // },
        // 借助mapActions生成对应的方法, 方法中会调用dispatch去联系actions
        // ...mapActions({incrementOdd:'jiaOdd',incrementWait:'jiaWait'})
        ...mapActions(['jiaOdd', 'jiaWait'])
    },
    mounted() {
        console.log('Count', this);
        const x = mapState({ sum: 'sum', school: 'school', subject: 'subject' })
        console.log(x);
    }
}
</script>

<style scoped>
button {
    margin-left: 5px;
}
</style>