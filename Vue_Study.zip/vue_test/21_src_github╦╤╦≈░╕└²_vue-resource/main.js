import Vue from 'vue'
import App from './App.vue'
import vueResource from 'vue-resource';

Vue.config.productionTip = false;
// 使用插件(这个插件是vue1版本常用的,用法和axios基本一致)
// 此插件使用后vue实例和组件实例身上会多出$http这个属性,用来发请求的
Vue.use(vueResource)
new Vue({
  render: h => h(App),
  beforeCreate() {
    Vue.prototype.$bus = this
  },
  mounted() {
    console.log('你好',this);
  }
}).$mount('#app')

