<template>
    <section class="jumbotron">
        <h3 class="jumbotron-heading">Search Github Users</h3>
        <div>
            <input type="text" v-model="keyword" placeholder="enter the name you search">&nbsp;
            <button @click="searchUsers">Search</button>
        </div>
    </section>
</template>

<script>
import axios from 'axios';
export default {
    name: 'Search',
    data() {
        return {
            keyword: ''
        }
    },
    methods: {
        searchUsers() {
            console.log('你好',this);
            this.$bus.$emit('updateUsersData', { isFirst: false, isLoading: true, errMsg: '', users: [] })
            this.$http.get(`https://api.github.com/search/users?q=${this.keyword}`).then(
                response => {
                    console.log('请求成功');
                    this.$bus.$emit('updateUsersData', { isLoading: false, errMsg: '', users: response.data.items })
                },
                error => {
                    console.log('请求失败');
                    this.$bus.$emit('updateUsersData', { isLoading: false, errMsg: error.message, users: [] })
                }
            )
        }
    }
}
</script>

