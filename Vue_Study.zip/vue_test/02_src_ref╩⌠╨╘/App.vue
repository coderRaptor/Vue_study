<template lang="">
    <div>
        <h1 ref="title">{{msg}}</h1>
        <button ref="btn" @click="showDOM">点我获取上面的DOM元素</button>
        <School ref="sch"/>
        <Student/>
    </div>
</template>
<script>
// 引入组件
import School from "./components/School.vue";
import Student from "./components/Student.vue";
export default {
  name: "App",
  components: { School, Student },
  data() {
    return {
      msg: "欢迎学习Vue!",
    };
  },
  methods: {
    showDOM(){
        console.log(this);//指向该组件实例对象
        console.log(this.$refs.title);
        console.log(this.$refs.btn);
        console.log(this.$refs.sch);//School组件的实例对象
    }
  },
};
</script>
