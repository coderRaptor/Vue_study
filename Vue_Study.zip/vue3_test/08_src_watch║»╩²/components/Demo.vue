<template>
    <!-- Vue3组件中的模板结构可以没有根标签 -->
    <h2>当前求和为:{{ sum }}</h2>
    <button @click="sum++">点我+1</button>
    <hr>
    <h2>当前的信息为:{{ msg }}</h2>
    <button @click="msg+='!'">修改信息</button>
    <hr>
    <h2>姓名:{{ person.name }}</h2>
    <h2>年龄:{{ person.age }}</h2>
    <h2>薪资:{{ person.job.j1.salary }}k</h2>
    <button @click="person.name+='~'">修改姓名</button>
    <button @click="person.age++">增长年龄</button>
    <button @click="person.job.j1.salary++">涨薪</button>
  </template>
  
  <script>
  import { reactive, ref, watch } from 'vue'
  export default {
    name: 'Demo',
    setup() {
      // 数据
      let sum = ref(0)
      let msg = ref('你好啊')
      const person = reactive({
        name:'张三',
        age:18,
        job:{
          j1:{
            salary:20
          }
        }
      })
      // 情况一: 监视 ref 所定义的一个响应式数据
      // watch(sum,(newVal,oldVal)=>{
      //   console.log('sum变了', newVal, oldVal);
      // },{immediate:true})

      // 情况二: 监视 ref 所定义的多个响应式数据
      watch([sum, msg],(newVal, oldVal)=>{
        console.log('sum或者msg变了', newVal, oldVal);
      })

      // 情况三: 监视reactive所定义的一个响应式数据的全部属性
            // 1.注意: 此处无法正确的获取oldVal
            // 2.注意: 如果监视是reactive返回的person代理对象本身,
            //          那么强制开启了深度监视(deep配置无效)
      // watch(person,(newVal,oldVal)=>{
      //   console.log('person变化了', newVal, oldVal);
      // },{deep:false}) //此处的deep配置无效

      // 情况四: 监视reactive所定义的一个响应式数据的某个属性
      // watch(()=>person.name,(newVal,oldVal)=>{
      //   console.log('person的name变化了',newVal,oldVal);
      // })

      // 情况五: 监视reactive所定义的一个响应式数据中的某些属性
      // watch(()=>[person.name, person.age],(newVal,oldVal)=>{
      //   console.log('person的name或age变化了', newVal, oldVal);
      // })
     
      // 特殊情况: 不是监视代理对象person本身,默认不是深度监视,deep配置有效
      watch(()=>person.job,(newVal,oldVal)=>{
        console.log('person的job变化了',newVal, oldVal);
      },{deep:true})
      // 返回一个对象(常用)
      return {
        sum,
        msg,
        person
      }
    }
  }
  </script>