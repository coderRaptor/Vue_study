<template>
  <h3>我是App组件</h3>
</template>

<script>
import { shallowReactive, reactive, readonly, toRefs, ref, isReadonly, isProxy, isReactive, isRef } from 'vue'
export default {
  name: 'App',
  setup() {
    const car = reactive({ name: 'Cadillac', price: 25 })
    let sum = ref(0)
    const car2 = readonly(car)

    console.log(isRef(sum));// true
    console.log(isReactive(car));// true
    console.log(isReadonly(car2));// true

    // isProxy判断是否由reactive或者readonly创建的代理
    // 因为这两个api都是用来Proxy，当然有shallow的也同理
    console.log(isProxy(car));// true
    console.log(isProxy(car2));// true
    console.log(isProxy(shallowReactive({ name: '阿蛮' })));// true
    console.log(isProxy(sum));// false
    return {
      ...toRefs(car)
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

.app {
  background-color: grey;
  padding: 10px;
}
</style>
