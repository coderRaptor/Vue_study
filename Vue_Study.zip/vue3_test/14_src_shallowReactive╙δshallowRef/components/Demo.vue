<template>
  <h4>{{ person }}</h4>
  <h2>姓名:{{ name }}</h2>
  <h2>年龄:{{ age }}</h2>
  <h2>薪资:{{ job.j1.salary }}k</h2>
  <button @click="name += '~'">修改姓名</button>
  <button @click="age++">增长年龄</button>
  <button @click="job.j1.salary++">涨薪</button>
</template>

<script>
import { reactive, toRef, toRefs, shallowReactive, shallowRef } from 'vue'
export default {
  name: 'Demo',
  setup() {
    // shallowReactive：只是处理对象最外层属性的响应式（浅层响应式）。
    const person = shallowReactive({
      name: '张三',
      age: 18,
      job: {
        j1: {
          salary: 20
        }
      }
    })
    // shallowRef：只处理基本数据类型的响应式，不进行对象的响应式处理，即遇到对象不会借助reactive，也不会借助shallowReactive。
    const ppp = shallowRef(0)
    console.log(ppp);//响应式
    const ppp2 = shallowRef({ x: 0 })
    console.log(ppp2);//非响应式,  .value是Object而不是Proxy
    return {
      person,
      ...toRefs(person)
    }
  }
}
</script>