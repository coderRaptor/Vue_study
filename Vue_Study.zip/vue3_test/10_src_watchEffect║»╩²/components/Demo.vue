<template>
    <!-- Vue3组件中的模板结构可以没有根标签 -->
    <h2>当前求和为:{{ sum }}</h2>
    <button @click="sum++">点我+1</button>
    <hr>
    <h2>当前的信息为:{{ msg }}</h2>
    <button @click="msg+='!'">修改信息</button>
    <hr>
    <h2>姓名:{{ person.name }}</h2>
    <h2>年龄:{{ person.age }}</h2>
    <h2>薪资:{{ person.job.j1.salary }}k</h2>
    <button @click="person.name+='~'">修改姓名</button>
    <button @click="person.age++">增长年龄</button>
    <button @click="person.job.j1.salary++">涨薪</button>
  </template>
  
  <script>
  import { reactive, ref, watch, watchEffect } from 'vue'
  export default {
    name: 'Demo',
    setup() {
      // 数据
      let sum = ref(0)
      let msg = ref('你好啊')
      const person = reactive({
        name:'张三',
        age:18,
        job:{
          j1:{
            salary:20
          }
        }
      })
      // watch(sum,(newVal,oldVal)=>{
      //   console.log('sum变了', newVal, oldVal);
      // },{immediate:true})
      // 监视回调过程依赖的响应式数据
      // 默认是在组件渲染之前执行,并且开始时先执行一次,之后当回调函数中依赖的响应式数据发生变化时,重新执行回调
      // 与computed类似,但是computed注重的是返回结果中依赖的响应式数据是否发生变化,
      // watchEffect注重的是回调函数执行过程中依赖的响应式数据是否发生变化
      // 简单来说就是 computed 注重返回值, watchEffect 注重过程
      watchEffect(()=>{
        const x1 = sum.value
        const x2 = person.job.j1.salary
        console.log('watchEffect配置的回调执行了');
      })
    

      return {
        sum,
        msg,
        person,
      }
    }
  }
  </script>