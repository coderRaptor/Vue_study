## 一、创建Vue3.0工程

##二、常用Composition API

### 1.拉开序幕的setup

1. 理解：Vue3.0中的一个新配置项，值为一个函数。
2. setup是所有==Composition API（组合API）==*表演的舞台”*。
3. 组件中所用到的：数据、方法等等，均要配置在setup中。
4. setup函数的两种返回值：
   1. 若返回一个对象，则对象中的属性、方法，在模板中均可以直接使用。（重点关注！）
   2. 若返回一个渲染函数：则可以自定义渲染内容。（了解）
5. 注意点：
   1. 尽量不要与Vue2.x配置混用
      - Vue2.x配置（data、methods、computed...）中==可以访问到==setup中的属性、方法。
      - 但在setup中==不能访问到==Vue2.x配置（data、methods、computed...）。
      - 如果有重名，setup优先。
   2. setup不能是一个async函数，因为async修饰的函数其返回值不再是return的对象，而是promise，模板看不到return对象中的属性。(配合异步引入组件时可以返回Promise对象)

### 2.ref函数

- 作用：定义一个响应式数据
- 语法：```const xxx = ref(initValue)```
  - 创建一个包含响应式数据的==引用对象（reference对象，简称ref对象）。
  - JS中操作数据：```xxx.value```
  - 模板中读取数据：不需要 .value ,直接：```<div>{{xxx}}</div>```
- 备注:
  - 接收的数据可以是：基本类型、也可以是对象类型。
  - 基本类型的数据：响应式依然是靠```Object.defineProperty()```的```get```与```set```完成的。
  - 对象类型的数据：内部*“**求助**”*了Vue3.0中的一个新函数——```reactive```函数。

### 3.reactive函数

- 作用：定义一个==对象类型的==响应式数据（基本数据类型不能用它，用```ref```函数）
- 语法：**```const 代理对象 = reactive(被代理对象)```**接收一个对象（或数组），返回一个==代理对象（Proxy的实例对象，简称proxy对象）==
- reactive定义的响应式数据是“深层次的”。
- 内部基于**ES6**的**Proxy**实现，==通过代理对象操作源对象内部数据进行操作==。

### 4.Vue3.0中的响应式原理

#### vue2.x的响应式

- 实现原理：

  - 对象类型：通过```Object.defineProperty()```对对象的已有属性值的读取、修改进行拦截（数据劫持）。

  - 数组类型：通过重新更新数组的一系列方法来实现拦截。（对改变原数组的方法进行了包裹）。

    ```js
    Object.defineProperty(data, 'count', {
        get(){},
    set(){}
    })
    ```
    
  
- 存在问题:

  - 新增属性、删除属性，界面不会更新。（只能通过Vue.set或this.$set）
  - 直接通过下标修改数组，界面不会自动更新。

#### Vue3.0的响应式

- 实现原理：

  - 通过**Proxy**（代理）：拦截对象中任意属性的变化，包括：属性值的读写、属性的添加、属性的删除等。

  - 通过**Reflect**（反射）：对源对象的属性进行操作。

  - MDN文档中描述的**Proxy**与**Reflect**：

    - Proxy：https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Proxy

    - Reflect：https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Reflect

      ```js
              // 模拟Vue3的响应式原理
              const person = {
                  name: '张三',
                  age: 18
              }
              // ES6中的Proxy,代理
              // 如果直接修改person(源对象),其操作一样反应到p身上,即增删改person,p(代理对象)会做同样操作,但无法捕获
              // 但是直接修改p(代理对象),能够用get/set/deleteProperty捕获到操作,并且通过操作映射到person身上
              // 所以使用代理对象间接修改源对象的同时能够捕获到数据(数据劫持),可以在此进行重新解析模板更新页面操作(响应式操作)
              const p = new Proxy(person, {
                  // 有人读取p的某个属性时调用
                  get(target, prop, receiver) {
                      //target是源对象,即person,prop是读取的属性名字符串
                      console.log(`有人读取了p身上的${prop}属性`);
                      return Reflect.get(target, prop, receiver)
                  },
                  // 有人修改p的某个属性、或给p追加某个属性时调用
                  set(target, prop, value, receiver) {
                      console.log(`有人修改或添加了p身上的${prop}属性`);
                      Reflect.set(target, prop, value, receiver)
                  },
                  // 有人删除p的某个属性时调用
                  deleteProperty(target, prop) {
                      // deleteProperty没有receiver参数,不用接收
                      console.log(`有人删除了p身上的${prop}属性`);
                      return Reflect.deleteProperty(target, prop)
                  }
              })
      
              // 测试为什么Vue3响应式要Reflect的reciver参数（Proxy和Reflect一般配套使用）
              const parent = {
                  name: '19Qingfeng',
                  get value() {
                      // 既然返回的是name,我们当然期望返回的是 obj 中的 name 而不是 parent 中的 name
                      return this.name;
                  },
              };
      
              const handler = {
                  // get中的receiver参数有两种情况,它表示触发陷阱时正确的上下文   1:代理对象 2:继承于代理对象的对象(receiver用于针对这种情况)
                  get(target, key, receiver) {
                      console.log(receiver === handler);//false
                      console.log(receiver === obj);//true
                      // Reflect.get参数中如果target对象中指定了getter，receiver则为getter调用时的this值(MDN文档)
                      // 显然这里target即parent,有指定value的getter(key的getter)
                      // 所以如果Reflect.get(target, key)会调用parent的value的getter,显然this是parent,返回的是'19Qingfeng'
                      // return Reflect.get(target, key);// '19Qingfeng'
      
                      // 但是我们log(obj.value)是想要拿到obj自己的name即'tangjincheng',
                      // 所以有必要修改target中value的getter的this,而receiver的作用就在于此,
                      // 把代理对象的getter中的receiver参数(此时情况是继承于代理对象的对象即 obj ),改变parent中value的getter中this执行,
                      // 这时候就能拿到obj的name了, 
                      return Reflect.get(target, key, receiver);// 'tangjincheng'
      
                      // 此外,如果get中的receiver参数是第一种情况即 代理对象,那么即使改变target中getter的this指向代理对象,
                      // 在这里是value的getter的this指向变为proxy代理对象,即return this.name 实际是 return proxy.name 即get(parent, name, 代理对象本身)
                      // 此时target中没有对应name的getter( 即get name(){} ), receiver不起作用,返回 '19Qingfeng'
                      // 相当于绕了一圈,结果和 target[key] 一致
                      // 所以一般程序员自己开发来说如果不是特殊情况 直接 return target[key] 性能更佳
                      // 但对于框架来说,它是不知道你传的target是长什么样的,也不知道有哪些getter/setter,所以框架底层写receiver进行了一个保证不会出错
                  },
              };
      
              const proxy = new Proxy(parent, handler);
      
              const obj = {
                  name: 'tangjincheng',
              };
      
              // 设置obj继承与parent的代理对象proxy
              Object.setPrototypeOf(obj, proxy);
      
              // log: tangjincheng
              console.log(obj.value);// 这一段结果很明显我们想要的是'tangjincheng'
      
      
              // 为什么Vue3底层框架用Reflect.defineProperty代替Object.defineProperty使用？
              // 此外对于对象追加一个属性操作来说
              // const obj = { a: 1, b: 2 }
              // 通过Object.defineProperty去操作
              //#region
              // Object.defineProperty(obj,'c',{
              //     get(){
              //         return 3
              //     }
              // })
              // // 下面如果不用try/catch直接报错,不能对对象的同一个属性重复定义
              // // 对于程序员一般定义某个对象来说很方便,能够直接告诉你已经写过定义了,可以及时改正
              // // 但是对于框架底层代码却有很大弊端
              // // 因为底层一般有上万行代码,底层开发人员开发或维护途中很难清楚记得是否定义过某个对象某个属性
              // // 所以如果一旦重复定义由于js单线程原因直接报错导致后面代码无法执行,会导致整个框架崩掉(降低了框架的健壮性)
              // // 只能不断用try/catch捕获解决,但是如果这样会导致很多地方不记得都用try/catch会导致底层代码try/catch满天飞
              // // 所以Reflect便能很好的解决这个弊端, 避免了满天的try/catch, ECMA组织也正在尝试把Object上的方法移植到Reflect上
              // try{
              //     Object.defineProperty(obj,'c',{
              //         get(){
              //             return 4
              //         }
              //     })
              // }catch(err){
              //     console.log(err);
              // }
              //#endregion
      
              // 通过Reflect.defineProperty去操作
              //#region
              // let x1 = Reflect.defineProperty(obj, 'c', {
              //     get() {
              //         return 3
              //     },
              // })
              // console.log(x1);//true
              // // 不会报错
              // // Reflect.defineProperty的返回值为boolean,会告诉你此操作是否成功
              // let x2 = Reflect.defineProperty(obj, 'c', {
              //     get() {
              //         return 4
              //     }
              // })
              // console.log(x2);//fasle
              // // 在不知道是否操作成功的情况下可以写判断
              // if(x2){
              //     console.log('某某某操作成功了');
              // }else{
              //     console.log('某某某操作失败了');
              // }
              //#endregion
      
              // 链接：https://www.zhihu.com/question/460133198/answer/2416115070
      ```

### 5.reactive对比ref

- 从定义数据角度对比:
  - **ref**用来定义:==**基本类型数据**==。
  - **reactive**用来定义：==**对象（或数组）类型数据**==。
  - 备注：**ref**也可以用来定义==**对象（或数组）类型数据**==，它内部会自动通过```reactive```转为==**代理对象**==。
- 从原理角度对比：
  - **ref**通过```Object.defineProperty()```的```get```与```set```来实现响应式（数据劫持）。
  - **reactive**通过使用==**Proxy**==来实现响应式（数据劫持），并通过==**Reflect**== 操作==**源对象**==内部的数据。
- 从使用角度对比：
  - **ref**定义的数据：操作数据==**需要**==**```.value```**，读取数据时模板中直接读取==**不需要**==**```.value```**。
  - **reactive**定义的数据：操作数据与读取数据：==**均不需要**==```.value```。

### 6.setup的两个注意点

- setup执行的时机
  - 在**beforeCreate**之前执行一次，里面**this**是```undefined```。
- setup的参数
  - props：值为对象，包含：组件外部传递过来，且组件内部声明接收了的属性。
  - context：上下文对象
    - attrs：值为对象，包含：组件外部传递过来，但没有在**props**配置中声明的属性，相当于Vue2中的```this.$attrs```。
    - slots：收到的插槽内容，相当于Vue2中的```this.$slots```。
    - emit：分发自定义事件的函数，相当于Vue2中的```this.$emit```。

### 7.计算属性与监视

#### 1.computed函数

- 与Vue2.x中computed配置功能一致但写法不一致

- 写法

  ```js
  setup() {
        // 数据
        const person = reactive({
          firstName:'张',
          lastName:'三'
        })
  
        // 计算属性---简写(没有考虑计算属性被修改的情况)
        person.fullName = computed(()=>{
          return person.firstName + '-' + person.lastName
        })
  
        // 计算属性完整写法
        person.fullName = computed({
          get(){
            return person.firstName + '-' + person.lastName
          },
          set(val){
            const nameArr = val.split('-')
            person.firstName = nameArr[0]
            person.lastName = nameArr[1]
          }
        })
    
        // 返回一个对象(常用)
        return {
          person
        }
      }
  ```

#### 2.watch函数

- 与Vue2.x中watch配置功能一致，写法不一致

- 两个小“坑”：

  - 监视reactive定义的响应式数据时（监视代理对象）：oldValue无法正确获取，强制开启深度监视（deep配置失效）

  - 监视reactive定义的响应式数据中某个属性时：deep配置有效

    ```js
    setup() {
          // 数据
          let sum = ref(0)
          let msg = ref('你好啊')
          const person = reactive({
            name:'张三',
            age:18,
            job:{
              j1:{
                salary:20
              }
            }
          })
          // 情况一: 监视 ref 所定义的一个响应式数据
          watch(sum,(newVal,oldVal)=>{
            console.log('sum变了', newVal, oldVal);
          },{immediate:true})
    
          // 情况二: 监视 ref 所定义的多个响应式数据
          watch([sum, msg],(newVal, oldVal)=>{
            console.log('sum或者msg变了', newVal, oldVal);
          })
    
          // 情况三: 监视reactive所定义的一个响应式数据的全部属性
                // 1.注意: 此处无法正确的获取oldVal
                // 2.注意: 如果监视是reactive返回的person代理对象本身,
                //          那么强制开启了深度监视(deep配置无效)
          watch(person,(newVal,oldVal)=>{
            console.log('person变化了', newVal, oldVal);
          },{deep:false}) //此处的deep配置无效
    
          // 情况四: 监视reactive所定义的一个响应式数据的某个属性
          watch(()=>person.name,(newVal,oldVal)=>{
            console.log('person的name变化了',newVal,oldVal);
          })
    
          // 情况五: 监视reactive所定义的一个响应式数据中的某些属性
          watch(()=>[person.name, person.age],(newVal,oldVal)=>{
            console.log('person的name或age变化了', newVal, oldVal);
          })
         
          // 特殊情况: 不是监视代理对象person本身,默认不是深度监视,deep配置有效
          watch(()=>person.job,(newVal,oldVal)=>{
            console.log('person的job变化了',newVal, oldVal);
          },{deep:true})
          // 返回一个对象(常用)
          return {
            sum,
            msg,
            person
          }
        }
    ```

#### 3.watchEffect函数

- watch的套路是: 既要指明监视的属性, 也要指明监视的回调。

- watchEffect的套路是：不用指明监视哪个属性，而是监视回调中依赖的响应式数据。

- watchEffect有点像computed：

  - 但computed注重的是计算出来的值（回调函数的返回值），所以必须要写返回值。
  - 而watchEffect更注重的是过程（回调函数的函数体），所以不用写返回值。

  ```js
  // 默认是在组件渲染之前执行,并且开始时先执行一次
  // 之后当回调函数中依赖的响应式数据发生变化时,则直接重新执行回调
  watchEffect(()=>{
          const x1 = sum.value
          const x2 = person.job.j1.salary
          console.log('watchEffect配置的回调执行了');
        })
  ```

#### 8.生命周期

- [生命周期](https://cn.vuejs.org/guide/essentials/lifecycle.html#lifecycle-diagram)

  > 注意区分组合式生命周期钩子和选项式生命周期钩子以及setup执行顺序,
  >
  > 其次与11_src_生命周期文件配合复习。
  >
  > ​		Vue3中响应式数据的初始化是在setup中完成的，生命周期钩子又分选项式和组合式，组合式需import引入并写在setup中，另外组合式生命周期钩子没有onBeforeCreate和onCreated，因为在setup写操作也可以达到一致效果，比如想在数据初始化前或后执行某些操作可以在设置响应式数据之前或进行操作，如reactive和ref之前或之后；
  >
  > ​		另外setup也是在选项式钩子beforeCreated之前执行，所以在选项式钩子beforeCreated当中可以访问到this和设置的响应式数据，如果是ref设置的数据可以不用.value,会自动解包,直接this.xxx即可;   
  >
  > ​		再者Vue2的生命周期中是开始第一步是new Vue,钩子created之后再检测是否配置el,没有则等待$mount, 在Vue3中开始第一步就要等mount完成选定挂载的容器再往下走; 
  >
  > ​		再其他就是它的销毁钩子改名了,叫beforeUnmount（onBeforeUnmount）卸载前的意思 以及 unmounted（onUnmounted）

#### 9.自定义hook函数

- 什么是hook？——本质是一个函数，把setup函数中使用的Composition API进行了封装。
- 类似于Vue2.x中的mixin。
- 自定义hook的优势：复用代码，让setup中的逻辑更加清楚易懂。

#### 10.toRef

- 作用：创建一个 ref 对象，其value值指向另一个对象中的某个属性。
- 语法：```const name = toRef(person, 'name')```
- 应用：要将响应式对象中的某个属性单独提供给外部使用时。
- 扩展：```toRefs```与```toRef```功能一致，但可以批量创建多个ref对象，给参数对象的最外层包装成 ref 对象，这些包装成的ref对象value的setter/getter对应参数对象最外层的属性，语法：```toRefs(person)```

![图解](C:\Users\86136\Desktop\vue3_test\13_src_toRef与toRefs\assets\图解.png)

### 三、其他 Composition API

#### 1.shallowReactive 与 shallowRef

- shallowReactive：只是处理对象最外层属性的响应式（浅层响应式）。
- shallowRef：只处理基本数据类型的响应式，不进行对象的响应式处理，即遇到对象不会借助reactive，也不会借助shallowReactive。
- 什么时候使用？
  - 如果有一个对象数据，结构比较深，但变化时只是外层属性变化 ===> shallowReactive。
  - 如果有一个对象数据，后续功能不会修改该对象中的属性，而是生新的对象来替换 ===> shallowRef。

#### 2.readonly 与 shallowReadonly

- readonly：让一个响应式数据变为只读（深只读）。

- shallowReadonly：让一个响应式数据变为只读的（浅只读）。

- 应用场景：不希望响应式数据被修改时，例如导入其他组件的响应式数据，但不希望在当前组件修改这些响应式数据时。

  ```js
  setup() {
      // 假设person是其他组件中弄过来的响应式数据
      const person = reactive({
        name: '张三',
        age: 18,
        job: {
          j1: {
            salary: 20
          }
        }
      })
      
      // 那么如果不希望影响原来的那个组件的响应式数据,但我这个组件想要读取这些数据,那么可以设置响应式数据只读
      // 可以到浏览器中Vue的devtools中查看可以得知修改数据是不可行的。
     
      // 特别注意的是这两api返回的引用虽然不一样,但是它们里面的数据是关联起来的
      // 比如说 shallowReadonly 浅层只读,深层可以修改,在这里改了 person1深层数据, person深层数据也会相应被修改
      // 1.readonly 深层只读
      // const person1 = readonly(person)
  
      // 2.shallowReadonly 浅层只读,深层可以修改,修改person1深层数据会引起person对应深层数据修改
      const person1 = shallowReadonly(person)
      console.log(person === person1);//false
  
      // 题外话：我们常说的数据没有响应式并不是不能修改数据，而是原数据被改了但页面没有引起模板重新解析导致页面的数据没有更新
      // 而这里是设置了响应式的原数据不允许修改，变只读
      return {
        person1,
        person
      }
    }
  ```

  

#### 3.toRaw 与 markRaw

- toRaw：
  - 作用：返回一个由```reactivve```生成的**响应式对象**所对应的新的**普通对象**，不改变原来的响应式对象。
  - 使用场景：用于读取响应式对象对应的普通对象，对这个普通对象的所有操作，不会引起页面更新。
- markRaw：
  - 作用：标记一个对象，使其永远不会再成为响应式对象。
  - 应用场景：
    - 有些值不应该被设置为响应式的，例如复杂的第三方类库等。
    - 当渲染具有不可变数据源的大列表是，跳过响应式转换可以提高性能。

```js
setup() {
    const person = reactive({
      name: '张三',
      age: 18,
      job: {
        j1: {
          salary: 20
        }
      }
    })
    // 返回一个由reactivve生成的响应式对象所对应的新的普通对象，不改变原来的响应式对象。
    const p = toRaw(person)
    // console.log(p,person);

    // 因为Vue3对象数据响应式使用Proxy的缘故,往后给这个响应式追加的数据也一样是响应式的
    // person.car = {carName:'Cadillac',price:25}
    // 但是如果我希望person追加的car属性不是响应式,markRaw就派上用场了
    // markRaw标记的数据永远不会被设置为响应式数据, 此时点击增加person.car.price只有原数据改变,不会引起页面更新
    // 只有其他响应式数据引起页面更新时才能看到页面上的车价被改
    person.car = markRaw({carName:'Cadillac', price:25})
    return {
      person
    }
  }
```



#### 4.customRef

- 作用：创建一个自定义的 ref，并对其依赖项跟踪和更新触发进行显示控制。

- 实现防抖效果：

  ```vue
  <template>
    <input type="text" v-model="keyword">
    <h4>{{ keyword }}</h4>
  </template>
  
  <script>
  import { customRef } from 'vue'
  export default {
    name: 'App',
    setup() {
      function myRef(value, delay) {
        let timer;
        return customRef((track, trigger) => {
          return {
            get() {
              console.log(`有人读取了${keyword}`);
              track()// 告诉Vue对此数据进行追踪,这样重新解析模板时遇到keyword才会重新读取从而调用get
              return value
            },
            set(newVal) {
              console.log(`有人修改了${keyword}`);
              clearTimeout(timer)
              timer = setTimeout(() => {
                value = newVal;
                trigger()// 告诉Vue去重新解析模板,以达到页面更新数据, 相当于响应式的设置
              }, delay)
            }
          }
        })
      }
      let keyword = myRef('hello', 500)
      console.log(keyword);
      return {
        keyword
      }
    }
  }
  </script>
  ```

#### 5.provide 与 inject

- 实现祖与后代组件间通信,注意是祖先传给后代，反之不行，其次父传子虽然可以但父传子一般用**props**，所以此法通常用于祖先给跨了一级及以上的后代组件传数据。

- 传给后代组件的响应式数据是引用值，在后代组件修改接收的数据会影响原祖组件的响应式数据变化。

- 套路：父组件有一个**```provide```**选项来提供数据，后代组件有一个**```inject```**选项来开始使用这些数据。（这两个api从vue中导入）

- 具体写法：

  - 祖组件中：

    ```js
    setup(){
        ......
        const car = reactive({name:'Cadillac', price:25})
        provide('car',car)//第一个参数是后代组件接收用的命名
        ......
    }
    ```

  - 后代组件中:

    ```js
    setup(){
        ......
        const car = inject('car')
        return {car}
        ......
    }
    ```

#### 6.响应式数据的判断

- **isRef**：检查一个值是否为一个**ref**对象
- **isReactive**：检查一个对象是否由**```reactive```**创建的响应式代理
- **isReadonly**：检查一个对象是否由**```readonly```**创建的只读代理
- **isProxy**：检查一个对象是否由**```reactive```**或者**```readonly```**创建的代理

### 四、Composition API的优势

#### 1.Options API 存在的问题

使用传统Options API中，新增或修改一个需求，就需要分别在data，methods，computed里修改。

#### 2.Compostion API 的优势

我们可以更加优雅地组织我们的代码，函数。让相关功能的代码更加有序的组织在一起。（结合hook函数正是体现了这点）

### 五、新的组件

#### 1.Fragment

- 在Vue2中：组件必须有一个根标签。
- 在Vue3中：组件可以没有根标签，如果没有根标签那么内部会将多个标签包含在一个**Fragment**虚拟元素中，在devtools中可以看到，但这个虚拟元素不参与渲染。
- 好处：减少标签层级嵌套，减少内存占用。

#### 2.Teleport

- 什么是Teleport？——```Teleport```是一种能够将我们的**组件html结构**移动到指定位置的技术。

  ```vue
  <!-- teleport: 瞬移,传送,空间移动,远距离传送 -->
          <!-- teleport标签不参与渲染,但其标签体内的标签和内容可以根据to属性瞬移放到任意标签中 -->
          <!-- 但功能可以写在这个组件中,很好用且常用 -->
          <!-- 这样就能根据页面上任意一个标签定位了,比如下面teleport内容就会追加到 body 标签体最后 -->
          <!-- 这样就可以放心根据 body 标签定位里面的内容了,不用担心组件嵌套多了定位混乱 -->
          <!-- to 里面可以写标签名也可以写 css 选择器,选择你要追加到页面哪个标签体中 -->
          <teleport to='body'>
              <div v-if="isShow" class="mask">
                  <div class="dialog">
                      <h3>我是一个弹窗</h3>
                      <h4>一些内容</h4>
                      <h4>一些内容</h4>
                      <h4>一些内容</h4>
                      <button @click="isShow = false">关闭弹窗</button>
                  </div>
              </div>
          </teleport>
  ```

#### 3.Suspense

- 等待异步组件时渲染一些额外内容，让应用有更好的用户体验

- 使用步骤：

  - 异步引入组件

    ```js
    import {defineAsyncComponent} from 'vue' 
    const Child = defineAsyncComponent(()=>import('./components/Child.vue'))// 异步引入
    ```

  - 使用```Suspense```包裹组件，并配置好**```default```**与**```fallback```**

    ```vue
    <template>
      <div class="app">
        <h3>我是（祖）组件</h3>
        <!-- 内置组件Suspense,里面有两个插槽,一个是默认展示,一个是未加载完默认展示的时候先展示的fallback应急计划展示 -->
        <Suspense>
          <template v-slot:default>
            <Child/>
          </template>
          <template v-slot:fallback>
              <h3>正在加载中,请稍等...</h3>
          </template>
        </Suspense>
      </div>
    </template>
    ```

### 六、其他

#### 1.全局API的转移

- Vue2.x有许多全局 **API** 和配置。

  - 例如：注册全局组件、注册全局指令等。

    ```js
    //注册全局组件
    Vue.component('MyButton', {
        data:()=>({
            count:0
        }),
        template:'<button @click="count++">Clicked {{ count }}</button>'
    })
    
    //注册全局指令
    Vue.dirctive('focus', {
        inserted: el => el.focus() 
    })
    ```

- Vue3.0中对这些 **API** 做出了调整：

  - 将全局的 **API** ，即：**```Vue.xxx```**调整到应用实例 **```app```** 上

    | 2.x全局 API （Vue）      | 3.x实例 API （app）         |
    | :----------------------- | :-------------------------- |
    | Vue.config.xxx           | app.config.xxx              |
    | Vue.config.productionTip | 移除                        |
    | Vue.component            | app.component               |
    | Vue.directive            | app.directive               |
    | Vue.mixin                | app.mixin                   |
    | Vue.use                  | app.use                     |
    | Vue.prototype            | app.config.globalProperties |

#### 2.其他改变

- **data** 选项应始终被声明为一个函数。

- 过渡类名的更改：

  - Vue2.x写法

    ```css
    .v-enter,
    .v-leave-to {
    	opacity: 0;
    }
    .v-leave,
    .v-enter-to {
        opacity: 0;
    }
    ```

  - Vue3.x写法

    ```css
    .v-enter-from,
    .v-leave-to {
        opacity: 0;
    }
    .v-leave-from,
    .v-enter-to {
        opacity: 0;
    }
    ```

- **移除 keyCode** 作为 **v-on** 的修饰符，同时也不再支持 **```config.keyCode```**

- **移除 ```v-on.native```** 修饰符

  - 父组件中绑定事件

    ```vue
    <MyComponent
      v-on:close="handleComponentEvent"
      v-on:click="handleNativeClickEvent"
    />
    ```

  - 子组件中声明自定义事件

    ```html
    <script>
    	export default {
            // 这里没有声明 click ,则Vue会把click事件当成原生事件
            // 只会把emits中声明的事件当成该组件的自定义事件
            emits:['close']
        }
    </script>
    ```

- **移除**过滤器**（filter）**

  >过滤器虽然看起来方便，但它需要一个自定义语法，打破大括号内表达式 “只是 JavaScript ” 的假设，这不仅有学习成本，而且有实现成本！建议用方法调用或计算属性去替换过滤器。

- ......



