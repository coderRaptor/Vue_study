<template>
  <div class="app">
    <h3>我是（祖）组件, {{ name }} --- {{ price }}</h3>
    <Child/>
  </div>
</template>

<script>
import { provide, reactive, toRefs,inject } from 'vue'
import Child from './components/Child.vue'
export default {
  name: 'App',
  components:{Child},
  setup() {
    const car = reactive({name:'Cadillac', price:25})
    provide('car1', car)
    // 这种方式只能往后代传,不能后代传祖先哦~~~
    // const p = inject('p1')
    // console.log(p);
    return {
      ...toRefs(car)
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.app{
  background-color: grey;
  padding: 10px;
}
</style>
