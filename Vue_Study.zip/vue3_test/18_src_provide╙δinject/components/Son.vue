<template>
  <div class="son">
    <h3>我是Son组件(孙), {{ name }} --- {{ price }}</h3>
  </div>
</template>

<script>
import {inject, toRefs, provide, reactive} from 'vue'
export default {
    name:'Son',
    setup() {
        const car = inject('car1')
        // const p = reactive({name:'哈哈哈'})
        // provide('p1',p)
        console.log(car);
        // 通过修改数据得知传过来的是祖组件数据的本体引用,不是克隆体
        // 所以修改inject传过来的数据会影响组件的provide的数据
        car.name = "BWM"
        return {
            ...toRefs(car)
        }
    }
}
</script>

<style>
.son{
  background-color: orange;
  padding: 10px;
}
</style>