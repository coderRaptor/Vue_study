<template>
  <input type="text" v-model="keyword">
  <h4>{{ keyword }}</h4>
</template>

<script>
import { customRef } from 'vue'
export default {
  name: 'App',
  setup() {
    function myRef(value, delay) {
      let timer;
      return customRef((track, trigger) => {
        return {
          get() {
            console.log(`有人读取了${keyword}`);
            track()// 告诉Vue对此数据进行追踪,这样重新解析模板时遇到keyword才会重新读取从而调用get
            return value
          },
          set(newVal) {
            console.log(`有人修改了${keyword}`);
            clearTimeout(timer)
            timer = setTimeout(() => {
              value = newVal;
              trigger()// 告诉Vue去重新解析模板,以达到页面更新数据, 相当于响应式的设置
            }, delay)
          }
        }
      })
    }
    let keyword = myRef('hello', 500)
    console.log(keyword);
    return {
      keyword
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
