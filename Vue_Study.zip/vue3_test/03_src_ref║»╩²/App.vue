<template>
  <!-- Vue3组件中的模板结构可以没有根标签 -->
  <h1>一个人的信息</h1>
  <h2>姓名: {{ name }}</h2>
  <h2>年龄: {{ age }}</h2>
  <h3>工作种类:{{ job.type }}</h3>
  <h3>工作薪水:{{ job.salary }}</h3>
  <button @click="changeInfo">修改人的信息</button>
</template>

<script>
import {ref} from 'vue'
// import {h} from 'vue'
export default {
  name: 'App',
  setup(props) {
    // 数据
    let name = ref('张三') //引用对象(全称: 引用实现的实例)
    let age = ref(18)
    let job = ref({
      type:'前端工程师',
      salary:'30k'
    })

    // 方法
    function changeInfo(){
      console.log(name,age);
      name.value = '李四'
      age.value = 48,
      job.value.type = 'UI设计师'
      console.log(job.value);
    }

    // 返回一个对象(常用)
    return {
      name,
      age,
      changeInfo,
      job
    }

    // 返回一个渲染函数
    // return ()=>h('h1', '尚硅谷')
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
