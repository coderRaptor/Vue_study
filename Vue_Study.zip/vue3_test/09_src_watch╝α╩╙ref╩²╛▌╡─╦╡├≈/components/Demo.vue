<template>
    <!-- Vue3组件中的模板结构可以没有根标签 -->
    <h2>当前求和为:{{ sum }}</h2>
    <button @click="sum++">点我+1</button>
    <hr>
    <h2>当前的信息为:{{ msg }}</h2>
    <button @click="msg+='!'">修改信息</button>
    <hr>
    <h2>姓名:{{ person.name }}</h2>
    <h2>年龄:{{ person.age }}</h2>
    <h2>薪资:{{ person.job.j1.salary }}k</h2>
    <button @click="person.name+='~'">修改姓名</button>
    <button @click="person.age++">增长年龄</button>
    <button @click="person.job.j1.salary++">涨薪</button>
  </template>
  
  <script>
  import { reactive, ref, watch } from 'vue'
  export default {
    name: 'Demo',
    setup() {
      // 数据
      let sum = ref(0)
      let msg = ref('你好啊')
      const person = ref({
        name:'张三',
        age:18,
        job:{
          j1:{
            salary:20
          }
        }
      })
      // watch(sum,(newVal,oldVal)=>{
      //   console.log('sum变了', newVal, oldVal);
      // },{immediate:true})

      // 注意这里的person是由ref弄出来的,里面的value才是借助reactive弄出来的Proxy实例
      // 此时默认监视的是person.value指向的一个引用地址值,想要进一步监视Proxy实例内部变化就要开启深度监视(deep:true)
      watch(person,(newVal,oldVal)=>{
        console.log('person变化了');
      },{deep:true})
      // 返回一个对象(常用)
      return {
        sum,
        msg,
        person
      }
    }
  }
  </script>