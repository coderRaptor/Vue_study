<template>
  <h4>person: {{ person }}</h4>
  <h2>姓名:{{ person.name }}</h2>
  <h2>年龄:{{ person.age }}</h2>
  <h2>薪资:{{ person.job.j1.salary }}k</h2>
  <button @click="person.name += '~'">修改姓名</button>
  <button @click="person.age++">增长年龄</button>
  <button @click="person.job.j1.salary++">涨薪</button>
  <button @click="person.car.price++">涨车价</button>
</template>

<script>
import { reactive, toRaw, markRaw } from 'vue'
export default {
  name: 'Demo',
  setup() {
    const person = reactive({
      name: '张三',
      age: 18,
      job: {
        j1: {
          salary: 20
        }
      }
    })
    // 返回一个由reactivve生成的响应式对象所对应的新的普通对象，不改变原来的响应式对象。
    const p = toRaw(person)
    // console.log(p,person);

    // 因为Vue3对象数据响应式使用Proxy的缘故,往后给这个响应式追加的数据也一样是响应式的
    // person.car = {carName:'Cadillac',price:25}
    // 但是如果我希望person追加的car属性不是响应式,markRaw就派上用场了
    // markRaw标记的数据永远不会被设置为响应式数据, 此时点击增加person.car.price只有原数据改变,不会引起页面更新
    // 只有其他响应式数据引起页面更新时才能看到页面上的车价被改
    person.car = markRaw({carName:'Cadillac', price:25})
    return {
      person
    }
  }
}
</script>