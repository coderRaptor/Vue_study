<template>
  <!-- Vue3组件中的模板结构可以没有根标签 -->
  <h2>当前求和为:{{ sum }}</h2>
  <button @click="sum++">点我+1</button>
</template>
  
<script>
import { reactive, ref, onBeforeMount, onMounted, onUnmounted, onBeforeUnmount, onBeforeUpdate, onUpdated } from 'vue'
export default {
  name: 'Demo',
  setup() {
    console.log('---setup');
    // 数据
    let sum = ref(0)
    const person = reactive({
      name:'张三'
    })
    // beforeCreate和Created没有组合形式api的生命周期钩子,直接写在setup中效果一致
    // 比如说如果想在初始化响应式数据之前或之后作一些操作,直接在setup中ref和reactive之前或之后做执行你想要的操作即可
    // 此外组合式生命周期钩子和选项式生命周期钩子可以一起写,并且同一生命周期时期前者先执行,但基本没人这么干,组合式和选项式选一种即可
    onBeforeMount(() => {
      console.log('---onBeforeMount');
      console.log(sum);
    })
    onMounted(() => {
      console.log('---onMounted');
    })
    onBeforeUpdate(() => {
      console.log('---onBeforeUpdate');
    })
    onUpdated(() => {
      console.log('---onUpdated');
    })
    onBeforeUnmount(() => {
      console.log('---onBeforeUnmount');
    })
    onUnmounted(() => {
      console.log('---onUnmounted');
    })
    return {
      sum,
      person
    }
  },
  // 选项式api形式, setup仍然会在它之前执行,具体参考Vue3生命周期图
  // beforeCreate(){
  //   console.log(this);//这里能访问this,并且能看到里面的数据.说明在setup中已经初始化响应式数据了
  //   console.log(this.sum);//通过this或在模板中访问ref自动浅层解包,不用写.value
  // }
}
</script>