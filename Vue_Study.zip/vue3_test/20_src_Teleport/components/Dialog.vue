<template>
    <div>
        <button @click="isShow = true">点我弹窗</button>
        <!-- teleport: 瞬移,传送,空间移动,远距离传送 -->
        <!-- teleport标签不参与渲染,但其标签体内的标签和内容可以根据to属性瞬移放到任意标签中 -->
        <!-- 但功能可以写在这个组件中,很好用且常用 -->
        <!-- 这样就能根据页面上任意一个标签定位了,比如下面teleport内容就会追加到 body 标签体最后 -->
        <!-- 这样就可以放心根据 body 标签定位里面的内容了,不用担心组件嵌套多了定位混乱 -->
        <!-- to 里面可以写标签名也可以写 css 选择器,选择你要追加到页面哪个标签体中 -->
        <teleport to='body'>
            <div v-if="isShow" class="mask">
                <div class="dialog">
                    <h3>我是一个弹窗</h3>
                    <h4>一些内容</h4>
                    <h4>一些内容</h4>
                    <h4>一些内容</h4>
                    <button @click="isShow = false">关闭弹窗</button>
                </div>
            </div>
        </teleport>
    </div>
</template>

<script>
import { ref } from 'vue'
export default {
    name: 'Dialog',
    setup() {
        let isShow = ref(false)
        return { isShow }
    }
}
</script>

<style>
.mask{
    position: absolute;
    top: 0;bottom: 0;left: 0;right: 0;
    background-color: rgba(0,0,0,0.35);
}
.dialog {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    text-align: center;
    width: 300px;
    height: 300px;
    background-color: greenyellow;
    padding: 10px;
}
</style>