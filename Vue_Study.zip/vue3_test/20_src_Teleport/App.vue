<template>
  <div class="app">
    <h3>我是（祖）组件</h3>
    <Child/>
  </div>
</template>

<script>
import Child from './components/Child'
export default {
  name: 'App',
  components:{Child},
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.app{
  background-color: grey;
  padding: 10px;
}
</style>
