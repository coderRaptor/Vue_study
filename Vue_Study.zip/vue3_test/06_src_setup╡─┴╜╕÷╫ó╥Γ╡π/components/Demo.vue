<template>
    <!-- Vue3组件中的模板结构可以没有根标签 -->
    <h1>一个人的信息</h1>
    <slot name="qwe"></slot>
    <h2>姓名: {{ person.name }}</h2>
    <h2>年龄: {{ person.age }}</h2>
    <button @click="test">测试一下该组件上的hello事件</button>
  </template>
  
  <script>
  import { reactive } from 'vue'
  export default {
    name: 'Demo',
    props:['msg'],//Vue3中接多了是undefined,接少了不报错但发出黄色警告
    emits:['hello'],//Vue3中要声明接收一下定义在该组件上的事件, 即使不接收也不影响执行,但是会有黄色警告
    beforeCreate() {
        console.log('---beforeCreate---');
    },
    setup(props,context) {
        // setup在beforeCreate之前执行,此时this是undefined
        console.log('---setup---',this);
        console.log('props',props);//组件外部传递过来并且用props配置项声明接收了的属性包装成一个代理对象proxy,即为setup中的props参数
        console.log('context',context);//此参数对象有attrs、emit、slots，对应Vue2中的$attrs、$emit、$slots
        // Vue2中的this.$attrs装的是组件外部传递过来但没有用props配置项声明接收的属性
        console.log('context.attrs',context.attrs);//因为school没有用props配置项接收,所以被存在了这里,context.attrs是个Proxy实例(代理对象)
        // Vue2中的$emit用来调用组件身上的自定义事件的

        // Vue2中的$slots是用来存放有哪些插槽内容的对象,Vue3会用Proxy包装一个代理对象
        console.log('context.slots',context.slots);

      // 数据
      const person = reactive({
        name:'张三',
        age:18,
      })
      function test(){
        context.emit('hello',666)//调用该Demo组件实例上的hello事件
      }
  
      // 返回一个对象(常用)
      return {
        person,
        test
      }
    }
  }
  </script>