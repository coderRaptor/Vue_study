<template>
  <div class="app">
    <h3>我是（祖）组件</h3>
    <!-- 内置组件Suspense,里面有两个插槽,一个是默认展示,一个是未加载完默认展示的时候先展示的fallback应急计划展示 -->
    <Suspense>
      <template v-slot:default>
        <Child/>
      </template>
      <template v-slot:fallback>
          <h3>正在加载中,请稍等...</h3>
      </template>
    </Suspense>
  </div>
</template>

<script>
// import Child from './components/Child'// 静态同步引用
import {defineAsyncComponent} from 'vue' 
const Child = defineAsyncComponent(()=>import('./components/Child.vue'))// 异步引入
export default {
  name: 'App',
  components:{Child},
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.app{
  background-color: grey;
  padding: 10px;
}
</style>
