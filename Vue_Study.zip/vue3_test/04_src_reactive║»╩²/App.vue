<template>
  <!-- Vue3组件中的模板结构可以没有根标签 -->
  <h1>一个人的信息</h1>
  <h2 v-show="person.name">姓名: {{ person.name }}</h2>
  <h2 v-show="person.sex">姓名: {{ person.sex }}</h2>
  <h2>年龄: {{ person.age }}</h2>
  <h3>工作种类:{{ person.job.type }}</h3>
  <h3>工作薪水:{{ person.job.salary }}</h3>
  <h3>爱好:{{ person.hobby }}</h3>
  <h3>测试一下c:{{ person.job.a.b.c }}</h3>
  <button @click="changeInfo">修改人的信息</button>
  <button @click="addSex">增加性别</button>
  <button @click="updateHobby">修改爱好</button>
  <button @click="deleteName">删除姓名</button>
</template>

<script>
import { reactive} from 'vue'
// import {h} from 'vue'
export default {
  name: 'App',
  setup() {
    // 数据
    const person = reactive({
      name:'张三',
      age:18,
      hobby:['抽烟','喝酒','看电影'],
      job:{
        type:'前端工程师',
        salary:'60k',
        a:{
          b:{
            c:666
          }
        }
      }
    })

    // 方法
    function changeInfo(){
      person.name = '李四',
      person.age = 48,
      person.job.type = 'UI设计师',
      person.job.salary = '60k',
      person.job.a.b.c = 999
    }
    function addSex(){
      person.sex = '男'
    }
    function updateHobby(){
      person.hobby[0] = '学习'
    }
    function deleteName(){
      delete person.name
    }
    // 返回一个对象(常用)
    return {
      person,
      changeInfo,
      addSex,
      updateHobby,
      deleteName
    }

    // 返回一个渲染函数
    // return ()=>h('h1', '尚硅谷')
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
