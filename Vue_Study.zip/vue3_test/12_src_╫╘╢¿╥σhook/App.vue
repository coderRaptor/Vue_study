<template>
  <button @click="isShow = !isShow">显示/隐藏</button>
  <Demo v-if="isShow"/>
  <hr>
  <Test></Test>
</template>

<script>
import Demo from './components/Demo'
import Test from './components/Test'
import {ref} from 'vue'
export default {
  name: 'App',
  components:{Demo,Test},
  setup(){
    let isShow = ref(true)
    return {isShow}
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
