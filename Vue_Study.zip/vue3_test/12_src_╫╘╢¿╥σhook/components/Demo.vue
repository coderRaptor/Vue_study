<template>
  <!-- Vue3组件中的模板结构可以没有根标签 -->
  <h2>当前求和为:{{ sum }}</h2>
  <button @click="sum++">点我+1</button>
  <hr>
  <h2>当时鼠标点击的坐标为: x: {{ point.x }}, y: {{ point.y }}</h2>
</template>
  
<script>
import { reactive, ref,onMounted } from 'vue'
import usePoint from '../hooks/usePoint'
export default {
  name: 'Demo',
  setup() {
    // console.log('---setup');
    // 数据
    let sum = ref(0)
    const point = usePoint()
    onMounted(()=>{
      console.log('我执行啦1');
    })
    onMounted(()=>{
      console.log('我执行啦2');
    })
    return {
      sum,
      point
    }
  },
}
</script>