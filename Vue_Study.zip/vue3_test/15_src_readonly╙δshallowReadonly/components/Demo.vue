<template>
  <h4>person: {{ person }}</h4>
  <h4>person1: {{ person1 }}</h4>
  <h2>姓名:{{ person1.name }}</h2>
  <h2>年龄:{{ person1.age }}</h2>
  <h2>薪资:{{ person1.job.j1.salary }}k</h2>
  <button @click="person1.name += '~'">修改姓名</button>
  <button @click="person1.age++">增长年龄</button>
  <button @click="person1.job.j1.salary++">涨薪</button>
</template>

<script>
import { reactive, toRef, toRefs,readonly, shallowReadonly } from 'vue'
export default {
  name: 'Demo',
  setup() {
    // 假设person是其他组件中弄过来的响应式数据
    const person = reactive({
      name: '张三',
      age: 18,
      job: {
        j1: {
          salary: 20
        }
      }
    })
    
    // 那么如果不希望影响原来的那个组件的响应式数据,但我这个组件想要读取这些数据,那么可以设置响应式数据只读
    // 可以到浏览器中Vue的devtools中查看可以得知修改数据是不可行的。
   
    // 特别注意的是这两api返回的引用虽然不一样,但是它们里面的数据是关联起来的
    // 比如说 shallowReadonly 浅层只读,深层可以修改,在这里改了 person1深层数据, person深层数据也会相应被修改
    // 1.readonly 深层只读
    // const person1 = readonly(person)

    // 2.shallowReadonly 浅层只读,深层可以修改,修改person1深层数据会引起person对应深层数据修改
    const person1 = shallowReadonly(person)
    console.log(person === person1);//false

    // 题外话：我们常说的数据没有响应式并不是不能修改数据，而是原数据被改了但页面没有引起模板重新解析导致页面的数据没有更新
    // 而这里是设置了响应式的原数据不允许修改，变只读
    return {
      person1,
      person
    }
  }
}
</script>